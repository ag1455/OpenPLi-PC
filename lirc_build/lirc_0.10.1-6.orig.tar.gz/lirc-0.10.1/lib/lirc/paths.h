#ifndef PATHS_H
#define PATHS_H
#define DATADIR          "/usr/local/share"
#define SYSCONFDIR       "/usr/local/etc"
#define VARRUNDIR        "/usr/local/var/run"
#define LOCALSTATEDIR    "/usr/local/var"
#define LIBDIR           "/usr/local/lib"
#endif
